package com.gx.service;

import com.gx.po.UserPo;

public interface UserService {

	public UserPo selectLogin(UserPo user);
	
}
