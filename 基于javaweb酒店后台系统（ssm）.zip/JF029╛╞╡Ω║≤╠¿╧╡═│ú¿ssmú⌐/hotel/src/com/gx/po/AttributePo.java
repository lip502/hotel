package com.gx.po;

public class AttributePo {
  

	private Integer id;
	
	private Integer far_id;
	
	private String attributeName;
	
	private String attributeDetailsName;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFar_id() {
		return far_id;
	}
	
	public void setFar_id(Integer far_id) {
		this.far_id = far_id;
	}
	
	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getAttributeDetailsName() {
		return attributeDetailsName;
	}

	public void setAttributeDetailsName(String attributeDetailsName) {
		this.attributeDetailsName = attributeDetailsName;
	}
	
	
	
	
	
	
}
