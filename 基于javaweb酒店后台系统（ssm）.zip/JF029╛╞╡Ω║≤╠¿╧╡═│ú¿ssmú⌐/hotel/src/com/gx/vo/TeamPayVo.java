package com.gx.vo;

public class TeamPayVo {
	
	private double stayMoney;
	
	private double changRoomMoney;
	
	private double otherMoney;
	
	private double payMoney;
	
	private double depositMoney;
	
	private double payRepairMoney;
	
	

	public double getStayMoney() {
		return stayMoney;
	}

	public void setStayMoney(double stayMoney) {
		this.stayMoney = stayMoney;
	}

	public double getChangRoomMoney() {
		return changRoomMoney;
	}

	public void setChangRoomMoney(double changRoomMoney) {
		this.changRoomMoney = changRoomMoney;
	}

	public double getOtherMoney() {
		return otherMoney;
	}

	public void setOtherMoney(double otherMoney) {
		this.otherMoney = otherMoney;
	}

	public double getPayMoney() {
		return payMoney;
	}

	public void setPayMoney(double payMoney) {
		this.payMoney = payMoney;
	}

	public double getDepositMoney() {
		return depositMoney;
	}

	public void setDepositMoney(double depositMoney) {
		this.depositMoney = depositMoney;
	}

	public double getPayRepairMoney() {
		return payRepairMoney;
	}

	public void setPayRepairMoney(double payRepairMoney) {
		this.payRepairMoney = payRepairMoney;
	}
	
}
